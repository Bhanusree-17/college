# College Classroom Manager

A beginner-friendly student management website with an HTML/CSS/JavaScript frontend, Express API, and MySQL database.

## Features
- Dashboard totals and department count
- Add, view, edit, and delete student records
- Search by name, roll number, email, department, or phone
- Filter by department and year
- Basic client/server validation
- Responsive layout for desktop and mobile

## Project structure
- `frontend/`: static website files
- `backend/`: Express API and MySQL setup

## Requirements
- Node.js LTS
- MySQL Server and MySQL Workbench
- VS Code (Live Server extension recommended)

## 1. Create the database
1. Start MySQL Server.
2. Open MySQL Workbench and connect to your local server.
3. Open `backend/schema.sql` and execute it.

## 2. Configure backend
1. Open `backend/.env`.
2. Replace `YOUR_MYSQL_PASSWORD` with the password for your MySQL user.
3. Open a terminal in VS Code and run:

```bash
cd backend
npm install
npm start
```

The API runs at `http://localhost:5000`. Visit `http://localhost:5000/api/health`; a successful response looks like:

```json
{"status":"ok","database":"connected"}
```

## 3. Run frontend
1. In VS Code, install the **Live Server** extension if you have not already.
2. Right-click `frontend/index.html`.
3. Select **Open with Live Server**.
4. The page should open at an address similar to `http://127.0.0.1:5500/frontend/index.html`.

If Live Server uses a different port/origin, update `FRONTEND_ORIGIN` in `backend/.env` to match the origin exactly, then restart the backend. Example: `http://127.0.0.1:5500`.

## 4. Troubleshooting
- `Cannot connect to backend`: keep `npm start` running and check `API_BASE_URL` in `frontend/script.js`.
- Database connection failed: check that MySQL is running, the database script was executed, and `.env` credentials are correct.
- CORS error: set `FRONTEND_ORIGIN` to the exact frontend origin and restart the backend.
- Roll number already exists: each student must have a unique roll number.

## 5. Publish later
GitHub Pages hosts only static frontend files; it cannot run the Express server or MySQL database. Deploy the backend to a Node.js hosting service and the database to a managed MySQL service. Then update `API_BASE_URL` in `frontend/script.js` to `https://YOUR-BACKEND-DOMAIN/api`, set `FRONTEND_ORIGIN` to the deployed frontend origin, and redeploy the backend.

Do not publish real student personal information without appropriate authorization, access controls, and security protections. This starter project has no login/authentication yet.
